# Grocery Product Detection — Training Code & Experiment Log

## Best Result

**Model:** `runs/exp1_strong_aug/weights/best.pt`
**Score:** `det=0.9528  cls=0.8189  combined=0.9126`
**Inference:** TTA + conf=0.001

```bash
python3 evaluate_tta.py runs/exp1_strong_aug/weights/best.pt --device cuda:0 --conf 0.001
```

---

## Critical Bug Fix (evaluate.py and all eval scripts)

All evaluation scripts had two bugs that made every score wrong:

**Bug 1 — maxDets capped at 100 (pycocotools default):**
```python
# BEFORE (wrong): silently drops predictions beyond 100 per image
ev.params.iouThrs = [0.5]
ev.evaluate(); ev.accumulate()

# AFTER (fixed):
ev.params.iouThrs = [0.5]
ev.params.maxDets = [1, 10, 1500]
ev.evaluate(); ev.accumulate()
```

**Bug 2 — Only category 0 evaluated for cls:**
```python
# BEFORE (wrong): only measures precision of category 0
prec = ev.eval["precision"][0, :, 0, 0, 2]

# AFTER (fixed): all 356 categories
prec = ev.eval["precision"][0, :, :, 0, 2]
```

**Impact on baseline scores:**

| metric | buggy | fixed |
|--------|-------|-------|
| det    | 0.825 | 0.947 |
| cls    | 1.000 | 0.781 |
| combined | 0.878 | 0.897 |

The bug made cls appear perfect (1.000) and severely underestimated det.
All 5 eval scripts have been patched: evaluate.py, evaluate_tta.py,
evaluate_conf_sweep.py, evaluate_ensemble.py, train_4x4090.py.

---

## Key Insight: Bottleneck Shifted

The original instructions said "cls is perfect, focus on detection."
After the fix: **det≈0.95 is strong, cls≈0.78–0.81 is the real bottleneck.**

---

## Experiment Results (all with fixed evaluator)

See `results.txt` for full table. Summary:

| experiment | combined | verdict |
|---|---|---|
| baseline 60ep | 0.8971 | starting point |
| exp1: 150ep strong aug | 0.9098 | +0.013, best static model |
| exp4: exp1 + 100ep extension | 0.9008 | overfit |
| exp5: cls_loss=2.0 | 0.9059 | hurt both metrics |
| exp6: imgsz=1920 | 0.9093 | cls↑ but det↓ |
| exp7: frozen backbone | 0.9107 | marginal +0.001 over exp1 |
| exp8: label_smoothing=0.1 | 0.9080 | backfired on small dataset |
| exp1 + TTA | 0.9118 | TTA helps (+0.002) |
| **exp1 + TTA + conf=0.001** | **0.9126** | **BEST** |
| ensemble exp1+exp6 | 0.9111 | worse than TTA alone |
| ensemble exp1+exp7 | 0.9086 | too similar, no diversity |

**What didn't work:**
- SK-110K pretraining → 356-class finetune: broken (1→356 class mismatch)
- SAHI/tiling, RT-DETR, YOLO11x, imgsz=1920, FP16 ONNX (from earlier runs)
- Note: old "TTA hurts cls" conclusion was entirely a bug artifact — TTA actually helps

**Conf sweep (exp1, no TTA):** det is flat from conf=0.001–0.020; cls is sensitive.
Use conf=0.001 in submission.

---

## File Guide

| file | purpose |
|------|---------|
| `train.py` | original baseline training script |
| `train_4x4090.py` | 4-GPU training with inline eval (also bug-fixed) |
| `train_exp1.py` | Exp 1: 150ep strong augmentation — **use this as base** |
| `train_exp2_*.py` | SK-110K pretrain + finetune (failed) |
| `train_exp3.py` | OIV7 backbone (weights lost, score ~0.881) |
| `train_exp4_ext.py` | Extended training from exp1 (overfit) |
| `train_exp5_cls.py` | cls_loss=2.0 from exp1 (worse) |
| `train_exp6_imgsz1920.py` | imgsz=1920 from exp1 (neutral) |
| `train_exp7_frozen.py` | Frozen backbone from exp1 (marginal gain) |
| `train_exp8_labelsmooth.py` | label_smoothing=0.1 from exp1 (worse) |
| `evaluate.py` | Standard eval — **bug-fixed** |
| `evaluate_tta.py` | TTA eval with --conf flag — **bug-fixed** |
| `evaluate_conf_sweep.py` | Conf threshold sweep — **bug-fixed** |
| `evaluate_ensemble.py` | WBF ensemble eval — **bug-fixed** |
| `results.txt` | Full experiment log |
| `instructions.md` | Original task instructions |
