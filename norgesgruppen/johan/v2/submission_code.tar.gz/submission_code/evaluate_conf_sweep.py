"""Experiment 6: Confidence threshold sweep."""
import argparse, contextlib, io, json, os, tempfile
import numpy as np, torch
from pathlib import Path
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval

_orig_load = torch.load
torch.load = lambda *a, **kw: _orig_load(*a, **{**kw, "weights_only": False})

from ultralytics import YOLO

ROOT = Path(__file__).parent

def evaluate_conf(model, preds_by_conf, gt_val, conf_threshold):
    # Filter predictions by conf threshold
    preds = [p for p in preds_by_conf if p["score"] >= conf_threshold]
    if not preds:
        return None, None, None

    with contextlib.redirect_stdout(io.StringIO()):
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump(gt_val, f); gt_path = f.name
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump(preds, f); pred_path = f.name
        coco_gt = COCO(gt_path)
        coco_dt = coco_gt.loadRes(pred_path)
        maps = []
        for use_cats in range(2):
            ev = COCOeval(coco_gt, coco_dt, "bbox")
            ev.params.useCats = use_cats
            ev.params.iouThrs = [0.5]
            ev.params.maxDets = [1, 10, 1500]
            ev.evaluate(); ev.accumulate()
            prec = ev.eval["precision"][0, :, :, 0, 2]
            maps.append(np.mean(prec[prec > -1]))
    os.unlink(gt_path); os.unlink(pred_path)
    det, cls = maps
    combined = det * 0.7 + cls * 0.3
    return det, cls, combined

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("model", help="Path to .pt or .onnx")
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()

    with open(ROOT / "annotations.json") as f:
        gt_data = json.load(f)

    val_dir = ROOT / "dataset/val/images"
    val_ids = {int(p.stem.split("_")[-1]) for p in val_dir.iterdir()
               if p.suffix.lower() in (".jpg", ".jpeg", ".png")}

    model = YOLO(args.model)
    # Collect all predictions with very low conf threshold
    all_preds = []
    for img in sorted(val_dir.iterdir()):
        if img.suffix.lower() not in (".jpg", ".jpeg", ".png"):
            continue
        image_id = int(img.stem.split("_")[-1])
        for r in model(str(img), device=args.device, imgsz=1280, conf=0.001, max_det=1500, verbose=False):
            if r.boxes is None:
                continue
            for i in range(len(r.boxes)):
                x1, y1, x2, y2 = r.boxes.xyxy[i].tolist()
                all_preds.append({
                    "image_id": image_id,
                    "category_id": int(r.boxes.cls[i].item()),
                    "bbox": [round(x1, 1), round(y1, 1), round(x2 - x1, 1), round(y2 - y1, 1)],
                    "score": round(float(r.boxes.conf[i].item()), 4),
                })

    gt_val = {
        "images": [i for i in gt_data["images"] if i["id"] in val_ids],
        "annotations": [a for a in gt_data["annotations"] if a["image_id"] in val_ids],
        "categories": gt_data["categories"],
    }

    print(f"Total predictions (conf>=0.001): {len(all_preds)}")
    print(f"\n{'conf':>8} | {'det':>8} | {'cls':>8} | {'combined':>10} | {'n_preds':>8}")
    print("-" * 55)

    best_combined = 0.0
    best_conf = 0.005
    for conf in [0.001, 0.003, 0.005, 0.01, 0.02, 0.05, 0.1]:
        det, cls, combined = evaluate_conf(model, all_preds, gt_val, conf)
        if combined is None:
            print(f"{conf:>8.3f} | {'N/A':>8} | {'N/A':>8} | {'N/A':>10}")
            continue
        n = sum(1 for p in all_preds if p["score"] >= conf)
        marker = " <-- BEST" if combined > best_combined else ""
        if combined > best_combined:
            best_combined = combined
            best_conf = conf
        print(f"{conf:>8.3f} | {det:>8.4f} | {cls:>8.4f} | {combined:>10.4f} | {n:>8}{marker}")

    print(f"\nBest conf threshold: {best_conf} (combined={best_combined:.4f})")

if __name__ == "__main__":
    main()
