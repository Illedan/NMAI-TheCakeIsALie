"""Ensemble evaluation using Weighted Box Fusion."""
import argparse, contextlib, io, json, os, tempfile
import numpy as np, torch
from pathlib import Path
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from ensemble_boxes import weighted_boxes_fusion

_orig_load = torch.load
torch.load = lambda *a, **kw: _orig_load(*a, **{**kw, "weights_only": False})

from ultralytics import YOLO

ROOT = Path(__file__).parent


def run_inference(model_path, val_dir, device):
    model = YOLO(model_path)
    results = {}
    for img in sorted(val_dir.iterdir()):
        if img.suffix.lower() not in (".jpg", ".jpeg", ".png"):
            continue
        image_id = int(img.stem.split("_")[-1])
        boxes, scores, labels, shape = [], [], [], None
        for r in model(str(img), device=device, imgsz=1280, conf=0.001, max_det=1500, verbose=False):
            shape = (r.orig_shape[1], r.orig_shape[0])  # W, H
            if r.boxes is None or len(r.boxes) == 0:
                continue
            for i in range(len(r.boxes)):
                x1, y1, x2, y2 = r.boxes.xyxy[i].tolist()
                W, H = shape
                boxes.append([x1/W, y1/H, x2/W, y2/H])
                scores.append(float(r.boxes.conf[i].item()))
                labels.append(int(r.boxes.cls[i].item()))
        results[image_id] = {"boxes": boxes, "scores": scores, "labels": labels, "shape": shape}
    return results


def evaluate_preds(preds, gt_data, val_ids):
    if not preds:
        print("No predictions"); return

    gt_val = {
        "images": [i for i in gt_data["images"] if i["id"] in val_ids],
        "annotations": [a for a in gt_data["annotations"] if a["image_id"] in val_ids],
        "categories": gt_data["categories"],
    }
    with contextlib.redirect_stdout(io.StringIO()):
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump(gt_val, f); gt_path = f.name
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump(preds, f); pred_path = f.name
        coco_gt = COCO(gt_path)
        coco_dt = coco_gt.loadRes(pred_path)
        maps = []
        for use_cats in range(2):
            ev = COCOeval(coco_gt, coco_dt, "bbox")
            ev.params.useCats = use_cats
            ev.params.iouThrs = [0.5]
            ev.params.maxDets = [1, 10, 1500]
            ev.evaluate(); ev.accumulate()
            prec = ev.eval["precision"][0, :, :, 0, 2]
            maps.append(np.mean(prec[prec > -1]))
    os.unlink(gt_path); os.unlink(pred_path)
    det, cls = maps
    combined = det * 0.7 + cls * 0.3
    print(f"det={det:.4f}  cls={cls:.4f}  combined={combined:.4f}  ({len(preds)} preds)")
    return combined


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("models", nargs="+", help="Paths to .pt models")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--iou_thr", type=float, default=0.5)
    parser.add_argument("--skip_box_thr", type=float, default=0.001)
    args = parser.parse_args()

    with open(ROOT / "annotations.json") as f:
        gt_data = json.load(f)

    val_dir = ROOT / "dataset/val/images"
    val_ids = {int(p.stem.split("_")[-1]) for p in val_dir.iterdir()
               if p.suffix.lower() in (".jpg", ".jpeg", ".png")}

    # Run inference with each model
    all_results = []
    for i, model_path in enumerate(args.models):
        print(f"Running inference with model {i+1}/{len(args.models)}: {model_path}")
        all_results.append(run_inference(model_path, val_dir, args.device))

    # Get all image ids
    image_ids = sorted(val_ids)

    # Apply WBF per image
    fused_preds = []
    for image_id in image_ids:
        boxes_list, scores_list, labels_list = [], [], []
        shape = None
        for model_results in all_results:
            r = model_results.get(image_id, {"boxes": [], "scores": [], "labels": [], "shape": None})
            boxes_list.append(r["boxes"])
            scores_list.append(r["scores"])
            labels_list.append(r["labels"])
            if r["shape"]:
                shape = r["shape"]

        if not shape or all(len(b) == 0 for b in boxes_list):
            continue

        boxes, scores, labels = weighted_boxes_fusion(
            boxes_list, scores_list, labels_list,
            iou_thr=args.iou_thr, skip_box_thr=args.skip_box_thr
        )

        W, H = shape
        for box, score, label in zip(boxes, scores, labels):
            x1, y1, x2, y2 = box[0]*W, box[1]*H, box[2]*W, box[3]*H
            fused_preds.append({
                "image_id": image_id,
                "category_id": int(label),
                "bbox": [round(x1, 1), round(y1, 1), round(x2-x1, 1), round(y2-y1, 1)],
                "score": round(float(score), 4),
            })

    print(f"\nEnsemble of {len(args.models)} models (iou_thr={args.iou_thr}):")
    evaluate_preds(fused_preds, gt_data, val_ids)


if __name__ == "__main__":
    main()
