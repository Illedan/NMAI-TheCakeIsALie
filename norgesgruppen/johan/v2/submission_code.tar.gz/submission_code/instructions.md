# Experiment Instructions

You are on a 4x RTX 4090 training server. Your job is to run experiments to improve a YOLOv8x grocery product detection model, evaluate results, and produce submission-ready ONNX files.

## Current state

Working directory: `/root/johan/`

Files already here:
- `train.py` — training script (modify or copy for experiments)
- `evaluate.py` — evaluation script (outputs det/cls/combined scores)
- `annotations.json` — ground truth annotations
- `dataset/` — YOLO-format dataset (train: 189 images, val: 21 images)
- `dataset.yaml` — dataset config (path should be `/root/johan/dataset`)
- `runs/yolov8x/weights/best.pt` — baseline model (60 epochs)
- Installed: `ultralytics==8.4.24`, `pycocotools`, `numpy==1.26.4`

Baseline scores: `det=0.825  cls=1.000  combined=0.878`

The bottleneck is detection mAP (category-agnostic box matching). Classification is already perfect on val. All improvements should focus on detection.

## Scoring metric

`combined = 0.7 * detection_mAP@0.5 + 0.3 * classification_mAP@0.5`

- Detection: category-agnostic (IoU ≥ 0.5, ignores class)
- Classification: category-aware (IoU ≥ 0.5 AND correct class)

## How to evaluate

Always evaluate with:
```bash
python3 evaluate.py runs/<experiment>/weights/best.pt --device cuda:0
```

## How to export ONNX

After training, export with:
```python
import torch
torch.load = (lambda _orig: lambda *a, **kw: _orig(*a, **{**kw, 'weights_only': False}))(torch.load)
from ultralytics import YOLO
model = YOLO('runs/<experiment>/weights/best.pt')
model.export(format='onnx', imgsz=1280, opset=17, simplify=True, half=False)
```

The exported file lands at `runs/<experiment>/weights/best.onnx`.

## Submission constraints

The submission sandbox has:
- L4 GPU (24GB), ultralytics==8.1.0, onnxruntime-gpu==1.20.0, torch==2.6.0
- ONNX required (.pt won't load on 8.1.0 if trained with 8.4.24)
- FP32 ONNX (FP16 is slower on L4)
- Max 420MB zip, 300s timeout, no network
- Blocked imports: os, subprocess. Use pathlib and json instead.

## Experiments to run

Run these in order. After each experiment, evaluate and record the score. If an experiment improves over baseline, use its weights as the starting point for later experiments.

### Experiment 1: More epochs + stronger augmentation

Copy `train.py` to `train_exp1.py` and change:
- `epochs=150`
- `copy_paste=0.3`
- `mixup=0.3`
- `erasing=0.4`
- `degrees=10.0`
- `flipud=0.5`
- Keep `patience=0, cos_lr=True, warmup_epochs=3, close_mosaic=20`

```bash
python3 train_exp1.py --epochs 150 --batch 16 --device 0,1,2,3 --name exp1_strong_aug
```

Then evaluate:
```bash
python3 evaluate.py runs/exp1_strong_aug/weights/best.pt --device cuda:0
```

Expected: +2-4% over baseline. ~25 minutes on 4x4090.

### Experiment 2: SK-110K pretraining → fine-tune

This is a two-stage approach: pretrain on ~110k grocery shelf images (single-class detection), then fine-tune on competition data.

**Step 2a: Download and prepare SK-110K**

Write a script that:
1. Downloads SK-110K dataset. The annotations CSV files are at:
   - `https://github.com/eg4000/SKU110K_CVPR19/releases/download/v1.0/annotations_train.csv`
   - `https://github.com/eg4000/SKU110K_CVPR19/releases/download/v1.0/annotations_val.csv`
   - `https://github.com/eg4000/SKU110K_CVPR19/releases/download/v1.0/annotations_test.csv`

   Images are at: `https://github.com/eg4000/SKU110K_CVPR19/releases/download/v1.0/SKU110K_fixed.tar.gz` (~27GB)

2. CSV format: `image_name,x1,y1,x2,y2,class,image_width,image_height`

3. Converts to YOLO format — single class (class 0 = product):
   - For each image, compute normalized center-x, center-y, width, height
   - Write one `.txt` label file per image
   - Symlink or copy images into `sk110k/train/images/` and `sk110k/val/images/`

4. Writes `sk110k_dataset.yaml` with `nc: 1, names: {0: product}`

**Step 2b: Pretrain on SK-110K**

```python
model = YOLO("yolov8x.pt")
model.train(
    data="sk110k_dataset.yaml",
    epochs=20,
    imgsz=1280,
    batch=32,
    device=[0,1,2,3],
    project="runs",
    name="sk110k_pretrain",
    exist_ok=True,
    degrees=3.0,
    mixup=0.1,
    copy_paste=0.05,
    close_mosaic=10,
    cos_lr=True,
    warmup_epochs=3,
    patience=5,
    verbose=True,
)
```

**Step 2c: Fine-tune on competition data**

Use the SK-110K pretrained weights as starting point. The model has 1 class from pretraining but ultralytics handles class count mismatch automatically when loading.

```python
model = YOLO("runs/sk110k_pretrain/weights/best.pt")
model.train(
    data="dataset.yaml",  # competition data, 356 classes
    epochs=150,
    imgsz=1280,
    batch=16,
    device=[0,1,2,3],
    project="runs",
    name="exp2_sk110k_finetune",
    exist_ok=True,
    # Same strong augmentation as exp1
    copy_paste=0.3,
    mixup=0.3,
    erasing=0.4,
    degrees=10.0,
    flipud=0.5,
    close_mosaic=20,
    cos_lr=True,
    warmup_epochs=3,
    weight_decay=0.0005,
    patience=0,
    verbose=True,
)
```

Then evaluate. Expected: +2-4% on detection mAP specifically.

### Experiment 3: Objects365 / Open Images pretrained backbone

Try alternative pretrained starting points instead of the default COCO weights:

```python
# Open Images v7 pretrained (ships with ultralytics)
model = YOLO("yolov8x-oiv7.pt")
model.train(
    data="dataset.yaml",
    epochs=150,
    # ... same settings as exp1
    name="exp3_oiv7",
)
```

If `yolov8x-oiv7.pt` isn't available, try `yolov8x-worldv2.pt` or search for Objects365 weights. The idea is more diverse pretraining = better features for dense detection.

### Experiment 4: TTA (test-time augmentation)

Quick test — no training needed. Modify the model predict call to add `augment=True`:

```bash
# In evaluate.py, change the model() call to add augment=True
# Then evaluate with existing best model
python3 evaluate_tta.py runs/yolov8x/weights/best.pt --device cuda:0
```

Also test TTA on whichever experiment gave the best result so far. If TTA helps, it needs to also be added to the submission `run.py` — but check that inference stays under 300s for 248 images on L4 (baseline is 81s, so ~3.5x TTA overhead is acceptable).

### Experiment 5: Multi-model ensemble with WBF

Once you have 2-3 trained models with different scores, ensemble them:

```bash
pip install ensemble-boxes
```

Write `evaluate_ensemble.py` that:
1. Runs inference with each model separately
2. For each image, collects all predictions from all models
3. Applies Weighted Box Fusion (WBF) to merge overlapping boxes:

```python
from ensemble_boxes import weighted_boxes_fusion

# Per image, normalize boxes to [0,1] range
# boxes_list = [model1_boxes, model2_boxes, ...]  (each: list of [x1,y1,x2,y2] normalized)
# scores_list = [model1_scores, model2_scores, ...]
# labels_list = [model1_labels, model2_labels, ...]
boxes, scores, labels = weighted_boxes_fusion(
    boxes_list, scores_list, labels_list,
    iou_thr=0.5, skip_box_thr=0.001
)
```

4. Evaluates the fused predictions with the same COCO metric

For submission, the `run.py` must load multiple ONNX models and apply WBF. Total zip must be under 420MB (so 2 models max at ~210MB each, or 3 smaller models).

### Experiment 6: Confidence threshold sweep

With the best model from above, sweep conf threshold:

```python
for conf in [0.001, 0.003, 0.005, 0.01, 0.02, 0.05]:
    # run evaluate with this conf threshold
    # (modify evaluate.py to accept --conf flag)
```

Pick the conf that maximizes combined score on val for the submission `run.py`.

## Recording results

After each experiment, append results to a file `results.txt`:

```
experiment          | det    | cls    | combined | notes
--------------------|--------|--------|----------|------
baseline (60ep)     | 0.8254 | 1.0000 | 0.8778   | yolov8x, COCO pretrain
exp1_strong_aug     | ...    | ...    | ...      | 150ep, strong aug
exp2_sk110k_ft      | ...    | ...    | ...      | SK-110K pretrain → fine-tune
...
```

## Final deliverable

Once you have the best model(s):
1. Export to ONNX (FP32, imgsz=1280)
2. If using ensemble: write a `run.py` that loads multiple ONNX models and applies WBF
3. If using single model: the existing `submission/run.py` pattern works, just swap the ONNX file
4. Package as `submission.zip` containing `run.py` and ONNX file(s), under 420MB

## What has been tried before and failed (do NOT repeat)

- SAHI/tiling: destroyed detection mAP (0.84 → 0.64)
- RT-DETR: OOM + 0 mAP after 30 epochs
- imgsz=1920: no benefit over 1280
- YOLO11x: slightly worse than YOLOv8x on ONNX
- Training on all images (no val split): inflates scores, can't evaluate properly
- FP16 ONNX: slower than FP32 on L4
