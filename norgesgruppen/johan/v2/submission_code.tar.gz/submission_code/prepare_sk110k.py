"""Download and prepare SK-110K dataset for pretraining."""
import csv, urllib.request, tarfile, pathlib, shutil, collections

ROOT = pathlib.Path(__file__).parent
SK_DIR = ROOT / "sk110k"

ANNO_URLS = {
    "train": "https://github.com/eg4000/SKU110K_CVPR19/releases/download/v1.0/annotations_train.csv",
    "val":   "https://github.com/eg4000/SKU110K_CVPR19/releases/download/v1.0/annotations_val.csv",
    "test":  "https://github.com/eg4000/SKU110K_CVPR19/releases/download/v1.0/annotations_test.csv",
}
IMAGES_URL = "https://github.com/eg4000/SKU110K_CVPR19/releases/download/v1.0/SKU110K_fixed.tar.gz"

def download(url, dest):
    dest = pathlib.Path(dest)
    if dest.exists():
        print(f"  Already exists: {dest}")
        return
    print(f"  Downloading {url} -> {dest}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    urllib.request.urlretrieve(url, dest)
    print(f"  Done: {dest}")

def csv_to_yolo(csv_path, images_src_dir, out_images_dir, out_labels_dir):
    """Convert SK-110K CSV to YOLO format labels."""
    out_images_dir.mkdir(parents=True, exist_ok=True)
    out_labels_dir.mkdir(parents=True, exist_ok=True)

    # Group annotations by image
    image_annos = collections.defaultdict(list)
    with open(csv_path) as f:
        reader = csv.reader(f)
        for row in reader:
            if len(row) < 8:
                continue
            name, x1, y1, x2, y2, cls, img_w, img_h = row[:8]
            try:
                x1, y1, x2, y2 = float(x1), float(y1), float(x2), float(y2)
                img_w, img_h = float(img_w), float(img_h)
            except ValueError:
                continue  # skip header
            image_annos[name].append((x1, y1, x2, y2, img_w, img_h))

    count = 0
    for img_name, annos in image_annos.items():
        src = images_src_dir / img_name
        if not src.exists():
            continue
        # Symlink image
        dst_img = out_images_dir / img_name
        if not dst_img.exists():
            dst_img.symlink_to(src.resolve())
        # Write label
        label_path = out_labels_dir / (pathlib.Path(img_name).stem + ".txt")
        with open(label_path, "w") as f:
            for x1, y1, x2, y2, img_w, img_h in annos:
                cx = (x1 + x2) / 2 / img_w
                cy = (y1 + y2) / 2 / img_h
                w  = (x2 - x1) / img_w
                h  = (y2 - y1) / img_h
                # Clamp to [0, 1]
                cx = max(0.0, min(1.0, cx))
                cy = max(0.0, min(1.0, cy))
                w  = max(0.0, min(1.0, w))
                h  = max(0.0, min(1.0, h))
                f.write(f"0 {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}\n")
        count += 1
    print(f"  Converted {count} images from {csv_path.name}")

def main():
    # Download annotation CSVs
    anno_dir = SK_DIR / "annotations"
    for split, url in ANNO_URLS.items():
        download(url, anno_dir / f"annotations_{split}.csv")

    # Download images tarball
    tar_path = SK_DIR / "SKU110K_fixed.tar.gz"
    download(IMAGES_URL, tar_path)

    # Extract images
    images_extract_dir = SK_DIR / "SKU110K_fixed"
    if not images_extract_dir.exists():
        print(f"Extracting {tar_path} ...")
        with tarfile.open(tar_path) as tf:
            tf.extractall(SK_DIR)
        print("Extraction done.")

    # Find the actual images directory (usually SKU110K_fixed/images)
    images_src_dir = images_extract_dir / "images"
    if not images_src_dir.exists():
        # Try alternative paths
        for candidate in images_extract_dir.rglob("*.jpg"):
            images_src_dir = candidate.parent
            break

    print(f"Images source: {images_src_dir}")

    # Convert train split (use SK-110K train for our train, SK-110K val for our val)
    for split in ["train", "val"]:
        csv_path = anno_dir / f"annotations_{split}.csv"
        out_img = SK_DIR / split / "images"
        out_lbl = SK_DIR / split / "labels"
        print(f"Processing {split}...")
        csv_to_yolo(csv_path, images_src_dir, out_img, out_lbl)

    # Write dataset yaml
    yaml_path = ROOT / "sk110k_dataset.yaml"
    yaml_path.write_text(f"""path: {SK_DIR}
train: train/images
val: val/images
nc: 1
names:
  0: product
""")
    print(f"Written: {yaml_path}")
    print("SK-110K preparation complete.")

if __name__ == "__main__":
    main()
