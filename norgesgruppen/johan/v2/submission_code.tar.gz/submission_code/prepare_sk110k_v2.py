"""
Prepare SK-110K dataset for YOLOv8 single-class pretraining.

Source tarball: http://trax-geometry.s3.amazonaws.com/cvpr_challenge/SKU110K_fixed.tar.gz
Images extracted to: /dev/shm/SKU110K_fixed/images/  (RAM, not disk)
Annotations at: /home/trainer/johan/SKU110K_fixed/annotations/

CSV format (no header):
    image_name, x1, y1, x2, y2, class, image_width, image_height

Output:
    /dev/shm/sk110k/train/images/  -> symlinks into /dev/shm/SKU110K_fixed/images/
    /dev/shm/sk110k/train/labels/  -> YOLO .txt (class 0, normalized xywh)
    /dev/shm/sk110k/val/images/
    /dev/shm/sk110k/val/labels/
    /home/trainer/johan/sk110k_dataset.yaml  -> points at /dev/shm/sk110k

Decisions:
- Single class (class 0 = product). All boxes in CSV are class "object".
- train CSV -> train split, val CSV -> val split. Test split unused.
- Images symlinked (not copied) to avoid doubling RAM usage.
- Boxes clamped to [0,1]; zero-area boxes skipped.
"""
import csv, pathlib, collections

ANNO_DIR   = pathlib.Path("/home/trainer/johan/SKU110K_fixed/annotations")
IMAGES_SRC = pathlib.Path("/dev/shm/SKU110K_fixed/images")
DST        = pathlib.Path("/dev/shm/sk110k")
YAML_PATH  = pathlib.Path("/home/trainer/johan/sk110k_dataset.yaml")

SPLITS = {
    "train": ANNO_DIR / "annotations_train.csv",
    "val":   ANNO_DIR / "annotations_val.csv",
}


def convert_split(split_name, csv_path):
    images_dst = DST / split_name / "images"
    labels_dst = DST / split_name / "labels"
    images_dst.mkdir(parents=True, exist_ok=True)
    labels_dst.mkdir(parents=True, exist_ok=True)

    # Group annotations by image name
    image_annos = collections.defaultdict(list)
    with open(csv_path, newline="") as f:
        for row in csv.reader(f):
            if len(row) < 8:
                continue
            name, x1, y1, x2, y2, _, img_w, img_h = row[:8]
            try:
                x1, y1, x2, y2 = float(x1), float(y1), float(x2), float(y2)
                img_w, img_h = float(img_w), float(img_h)
            except ValueError:
                continue
            if img_w <= 0 or img_h <= 0:
                continue
            image_annos[name].append((x1, y1, x2, y2, img_w, img_h))

    n_images, n_boxes, n_skipped = 0, 0, 0
    for img_name, annos in image_annos.items():
        src_img = IMAGES_SRC / img_name
        if not src_img.exists():
            n_skipped += 1
            continue

        dst_img = images_dst / img_name
        if not dst_img.exists():
            dst_img.symlink_to(src_img.resolve())

        label_path = labels_dst / (pathlib.Path(img_name).stem + ".txt")
        with open(label_path, "w") as f:
            for x1, y1, x2, y2, img_w, img_h in annos:
                cx = (x1 + x2) / 2 / img_w
                cy = (y1 + y2) / 2 / img_h
                w  = (x2 - x1) / img_w
                h  = (y2 - y1) / img_h
                # Clamp and skip degenerate boxes
                w = max(0.001, min(1.0, w))
                h = max(0.001, min(1.0, h))
                cx = max(w/2, min(1 - w/2, cx))
                cy = max(h/2, min(1 - h/2, cy))
                f.write(f"0 {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}\n")
                n_boxes += 1
        n_images += 1

    print(f"  {split_name}: {n_images} images, {n_boxes} boxes "
          f"({n_boxes/max(n_images,1):.1f} avg boxes/image), {n_skipped} skipped")


def main():
    print("Preparing SK-110K...")
    for split_name, csv_path in SPLITS.items():
        convert_split(split_name, csv_path)

    YAML_PATH.write_text(
        f"path: {DST}\n"
        "train: train/images\n"
        "val: val/images\n"
        "nc: 1\n"
        "names:\n"
        "  0: product\n"
    )
    print(f"Dataset YAML: {YAML_PATH}")
    print("Done.")


if __name__ == "__main__":
    main()
