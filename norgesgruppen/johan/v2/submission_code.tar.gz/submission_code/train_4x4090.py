"""
YOLOv8x baseline trainer — 4x RTX 4090 DDP.

Metric: 0.7 * det_mAP@0.5 + 0.3 * cls_mAP@0.5  (via pycocotools)

Usage:
    python train_4x4090.py
    python train_4x4090.py --name experiment_name
"""
import argparse, contextlib, io, json, os, shutil, tempfile
import numpy as np
import torch
from pathlib import Path

_orig_load = torch.load
torch.load = lambda *args, **kwargs: _orig_load(*args, **{**kwargs, "weights_only": False})
os.environ["WANDB_DISABLED"] = "true"

from ultralytics import YOLO
import ultralytics.utils.callbacks.raytune
ultralytics.utils.callbacks.raytune.callbacks = {}
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval

# ── paths ──────────────────────────────────────────────────────────────────────
ROOT      = Path(__file__).parent
DATA_YAML = ROOT / "dataset.yaml"
ANN_FILE  = ROOT / "annotations.json"
VAL_DIR   = ROOT / "dataset/val/images"

# ── config ─────────────────────────────────────────────────────────────────────
MODEL     = "yolov8x.pt"
IMGSZ     = 1280
EPOCHS    = 150
BATCH     = 16       # 4 per GPU x 4 GPUs (24GB VRAM limit)
EVAL_EVERY = 5

# ── build val ground truth once ────────────────────────────────────────────────
with open(ANN_FILE) as f:
    gt_data = json.load(f)

val_ids = {int(p.stem.split("_")[-1]) for p in VAL_DIR.iterdir()
           if p.suffix.lower() in (".jpg", ".jpeg", ".png")}

gt_val = {
    "images":      [img for img in gt_data["images"]      if img["id"] in val_ids],
    "annotations": [ann for ann in gt_data["annotations"] if ann["image_id"] in val_ids],
    "categories":  gt_data["categories"],
}

# ── custom eval callback ────────────────────────────────────────────────────────
best_combined = 0.0

def eval_val(trainer):
    global best_combined
    epoch = trainer.epoch + 1
    if epoch % EVAL_EVERY != 0 and epoch != trainer.epochs:
        return

    ckpt = trainer.best if Path(str(trainer.best)).exists() else trainer.last
    model = YOLO(str(ckpt))

    preds = []
    for img in sorted(VAL_DIR.iterdir()):
        if img.suffix.lower() not in (".jpg", ".jpeg", ".png"):
            continue
        image_id = int(img.stem.split("_")[-1])
        for r in model(str(img), device="cuda:0", imgsz=IMGSZ,
                       conf=0.005, max_det=1500, verbose=False):
            if r.boxes is None:
                continue
            for i in range(len(r.boxes)):
                x1, y1, x2, y2 = r.boxes.xyxy[i].tolist()
                preds.append({
                    "image_id":   image_id,
                    "category_id": int(r.boxes.cls[i].item()),
                    "bbox":  [round(x1,1), round(y1,1),
                               round(x2-x1,1), round(y2-y1,1)],
                    "score": round(float(r.boxes.conf[i].item()), 4),
                })

    if not preds:
        print(f"\n[Epoch {epoch}] No predictions"); return

    with contextlib.redirect_stdout(io.StringIO()):
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump(gt_val, f);  gt_path = f.name
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump(preds, f);   pred_path = f.name
        coco_gt = COCO(gt_path)
        coco_dt = coco_gt.loadRes(pred_path)
        maps = []
        for use_cats in range(2):
            ev = COCOeval(coco_gt, coco_dt, "bbox")
            ev.params.useCats = use_cats
            ev.params.iouThrs = [0.5]
            ev.params.maxDets = [1, 10, 1500]
            ev.evaluate(); ev.accumulate()
            prec = ev.eval["precision"][0, :, :, 0, 2]
            maps.append(np.mean(prec[prec > -1]))
    os.unlink(gt_path); os.unlink(pred_path)

    det, cls = maps
    combined = det * 0.7 + cls * 0.3
    tag = ""
    if combined > best_combined:
        best_combined = combined
        ckpt_dir = Path(trainer.save_dir) / "checkpoints"
        ckpt_dir.mkdir(exist_ok=True)
        shutil.copy(str(ckpt), ckpt_dir / "best_combined.pt")
        tag = "  ← best"

    print(f"\n[Epoch {epoch}] det={det:.4f}  cls={cls:.4f}  "
          f"combined={combined:.4f}  best={best_combined:.4f}"
          f"  ({len(preds)} preds){tag}")

    with open(Path(trainer.save_dir) / "scores.txt", "a") as f:
        f.write(f"epoch={epoch} det={det:.4f} cls={cls:.4f} combined={combined:.4f}\n")

# ── train ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", default="yolov8x_4x4090_baseline")
    args = parser.parse_args()

    model = YOLO(MODEL)
    model.add_callback("on_fit_epoch_end", eval_val)
    model.train(
        data    = str(DATA_YAML),
        epochs  = EPOCHS,
        imgsz   = IMGSZ,
        batch   = BATCH,
        device  = [0, 1, 2, 3],
        project = str(ROOT / "runs"),
        name    = args.name,
        exist_ok = True,
        # augmentation
        degrees     = 5.0,
        mixup       = 0.15,
        copy_paste  = 0.1,
        close_mosaic = 20,
        cos_lr        = True,
        warmup_epochs = 3,
        weight_decay  = 0.0005,
        patience = 0,
        plots   = True,
        verbose = True,
    )
