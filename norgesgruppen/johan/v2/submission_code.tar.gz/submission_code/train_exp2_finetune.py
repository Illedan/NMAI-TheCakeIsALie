"""Experiment 2b: Fine-tune on competition data after SK-110K pretraining."""
import argparse, os, torch
from pathlib import Path

_orig_load = torch.load
torch.load = lambda *a, **kw: _orig_load(*a, **{**kw, "weights_only": False})
os.environ["WANDB_DISABLED"] = "true"

from ultralytics import YOLO
import ultralytics.utils.callbacks.raytune
ultralytics.utils.callbacks.raytune.callbacks = {}

ROOT = Path(__file__).parent

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--pretrain_weights", default="runs/sk110k_pretrain/weights/best.pt")
    args = parser.parse_args()

    weights = ROOT / args.pretrain_weights
    model = YOLO(str(weights))
    model.train(
        data=str(ROOT / "dataset.yaml"),
        epochs=150,
        imgsz=1280,
        batch=16,
        device=[0, 1, 2, 3],
        project=str(ROOT / "runs"),
        name="exp2_sk110k_finetune",
        exist_ok=True,
        copy_paste=0.3,
        mixup=0.3,
        erasing=0.4,
        degrees=10.0,
        flipud=0.5,
        close_mosaic=20,
        lr0=0.01,
        lrf=0.01,
        cos_lr=True,
        warmup_epochs=3,
        weight_decay=0.0005,
        patience=0,
        verbose=True,
    )
