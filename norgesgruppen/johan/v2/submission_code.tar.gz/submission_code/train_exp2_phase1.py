"""
Exp2 Phase 1: Freeze SK-110K backbone, train head only on competition data.

Problem: 1→356 class transition reinitialises the detection head. With an
unfrozen backbone, gradients are split across all layers and the head gets
too little signal to learn 356 classes quickly.

Fix: freeze the backbone (layers 0-9) so 100% of gradient goes to the
neck+head. After 50 epochs the head should have converged on 356 classes,
then phase 2 unfreezes everything for full fine-tuning.

freeze=10: freezes layers 0-9 (backbone). Neck (10-21) + head (22) are trained.
"""
import os, torch
from pathlib import Path

_orig_load = torch.load
torch.load = lambda *a, **kw: _orig_load(*a, **{**kw, "weights_only": False})
os.environ["WANDB_DISABLED"] = "true"

from ultralytics import YOLO
import ultralytics.utils.callbacks.raytune
ultralytics.utils.callbacks.raytune.callbacks = {}

ROOT = Path(__file__).parent

if __name__ == "__main__":
    model = YOLO(str(ROOT / "runs/sk110k_pretrain/weights/best.pt"))
    model.train(
        data=str(ROOT / "dataset.yaml"),
        epochs=50,
        imgsz=1280,
        batch=16,
        device=[0, 1, 2, 3],
        project=str(ROOT / "runs"),
        name="exp2_phase1",
        exist_ok=False,
        freeze=10,           # freeze backbone (layers 0-9), train neck+head
        lr0=0.01,            # full LR — head is randomly initialised
        lrf=0.01,
        cos_lr=True,
        warmup_epochs=3,
        weight_decay=0.0005,
        copy_paste=0.3,
        mixup=0.3,
        erasing=0.4,
        degrees=10.0,
        flipud=0.5,
        close_mosaic=20,
        patience=0,
        verbose=True,
    )
