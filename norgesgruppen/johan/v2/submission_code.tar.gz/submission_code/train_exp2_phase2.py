"""
Exp2 Phase 2: Full fine-tuning after head warm-up.

Starts from phase1 best.pt (head already converged on 356 classes),
unfreezes the backbone, and fine-tunes everything at a lower LR to
avoid destroying the SK-110K detection features.
"""
import os, torch
from pathlib import Path

_orig_load = torch.load
torch.load = lambda *a, **kw: _orig_load(*a, **{**kw, "weights_only": False})
os.environ["WANDB_DISABLED"] = "true"

from ultralytics import YOLO
import ultralytics.utils.callbacks.raytune
ultralytics.utils.callbacks.raytune.callbacks = {}

ROOT = Path(__file__).parent

if __name__ == "__main__":
    model = YOLO(str(ROOT / "runs/exp2_phase1/weights/best.pt"))
    model.train(
        data=str(ROOT / "dataset.yaml"),
        epochs=100,
        imgsz=1280,
        batch=16,
        device=[0, 1, 2, 3],
        project=str(ROOT / "runs"),
        name="exp2_phase2",
        exist_ok=False,
        # No freeze — train everything
        lr0=0.001,           # lower LR to preserve SK-110K backbone features
        lrf=0.01,
        cos_lr=True,
        warmup_epochs=3,
        weight_decay=0.0005,
        copy_paste=0.3,
        mixup=0.3,
        erasing=0.4,
        degrees=10.0,
        flipud=0.5,
        close_mosaic=20,
        patience=0,
        verbose=True,
    )
