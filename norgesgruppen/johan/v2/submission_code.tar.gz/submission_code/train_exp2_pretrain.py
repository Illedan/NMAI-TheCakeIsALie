"""Experiment 2a: Pretrain on SK-110K."""
import os, torch
from pathlib import Path

_orig_load = torch.load
torch.load = lambda *a, **kw: _orig_load(*a, **{**kw, "weights_only": False})
os.environ["WANDB_DISABLED"] = "true"

from ultralytics import YOLO
import ultralytics.utils.callbacks.raytune
ultralytics.utils.callbacks.raytune.callbacks = {}

ROOT = Path(__file__).parent

if __name__ == "__main__":
    model = YOLO(str(ROOT / "yolov8x.pt"))
    model.train(
        data=str(ROOT / "sk110k_dataset.yaml"),
        epochs=20,
        imgsz=1280,
        batch=16,
        device=[0, 1, 2, 3],
        project=str(ROOT / "runs"),
        name="sk110k_pretrain",
        exist_ok=True,
        degrees=3.0,
        mixup=0.1,
        copy_paste=0.05,
        close_mosaic=10,
        cos_lr=True,
        warmup_epochs=3,
        patience=5,
        save_period=10,
        verbose=True,
    )
