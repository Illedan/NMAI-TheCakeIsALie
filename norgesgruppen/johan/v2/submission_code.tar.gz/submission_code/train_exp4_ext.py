"""
Exp4: Extend exp1_strong_aug with lower LR.

Start from exp1's best.pt (combined=0.8843) and continue training for
100 more epochs at lr0=0.001. The cosine schedule in exp1 bottomed out
at ~0.0001 — a fresh cosine from 0.001 gives the model another chance
to refine weights without the large gradient steps that caused earlier
oscillation.

Same strong augmentation as exp1 to avoid distribution shift.
"""
import os, torch
from pathlib import Path

_orig_load = torch.load
torch.load = lambda *a, **kw: _orig_load(*a, **{**kw, "weights_only": False})
os.environ["WANDB_DISABLED"] = "true"

from ultralytics import YOLO
import ultralytics.utils.callbacks.raytune
ultralytics.utils.callbacks.raytune.callbacks = {}

ROOT = Path(__file__).parent

if __name__ == "__main__":
    model = YOLO(str(ROOT / "runs/exp1_strong_aug/weights/best.pt"))
    model.train(
        data=str(ROOT / "dataset.yaml"),
        epochs=100,
        imgsz=1280,
        batch=16,
        device=[0, 1, 2, 3],
        project=str(ROOT / "runs"),
        name="exp4_ext_exp1",
        exist_ok=False,
        lr0=0.001,
        lrf=0.01,
        cos_lr=True,
        warmup_epochs=1,
        weight_decay=0.0005,
        copy_paste=0.3,
        mixup=0.3,
        erasing=0.4,
        degrees=10.0,
        flipud=0.5,
        close_mosaic=10,
        patience=0,
        verbose=True,
    )
