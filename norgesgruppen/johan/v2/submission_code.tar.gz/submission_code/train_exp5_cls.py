"""Experiment 5: Higher cls_loss_gain from exp1 weights — targets classification bottleneck."""
import os, torch
from pathlib import Path

_orig_load = torch.load
torch.load = lambda *a, **kw: _orig_load(*a, **{**kw, "weights_only": False})
os.environ["WANDB_DISABLED"] = "true"

from ultralytics import YOLO
import ultralytics.utils.callbacks.raytune
ultralytics.utils.callbacks.raytune.callbacks = {}

ROOT = Path(__file__).parent

if __name__ == "__main__":
    model = YOLO(str(ROOT / "runs/exp1_strong_aug/weights/best.pt"))
    model.train(
        data=str(ROOT / "dataset.yaml"),
        epochs=100,
        imgsz=1280,
        batch=16,
        device=[0, 1, 2, 3],
        project=str(ROOT / "runs"),
        name="exp5_cls_gain",
        exist_ok=True,
        # Same strong augmentation as exp1
        copy_paste=0.3,
        mixup=0.3,
        erasing=0.4,
        degrees=10.0,
        flipud=0.5,
        close_mosaic=20,
        cos_lr=True,
        warmup_epochs=1,
        weight_decay=0.0005,
        patience=20,
        # Classification loss boost — targets the bottleneck
        cls=2.0,
        plots=True,
        verbose=True,
    )
